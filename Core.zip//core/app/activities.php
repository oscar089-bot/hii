<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class activities extends Model
{
    protected $table="activities";
}
