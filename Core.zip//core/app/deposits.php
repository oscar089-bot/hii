<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class deposits extends Model
{
    protected $table="deposits";
}
