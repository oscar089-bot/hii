<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class crypto_dep extends Model
{
    protected $table="crypto_payments";
}
