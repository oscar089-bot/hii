
<!--<div class="header-top-area" style="background-color: #059; " >-->
<!--    <div class="" style="background-color: transparent;">-->
        
<!--        <div class="container-fluid" style="background-color: transparent; min-width: 100%;">                        -->
<!--            <div class="row" >-->
<!--                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="margin-top: 8px; " align="center">-->
<!--                    <a href="http://daimondhubplus.com" style="color:#FFF;">-->
<!--                        <img src="/img/logo.jpg" alt="DaimondHubPlus" style="border-radius:50%; height: 40px; width: 40px;"> -->
<!--                        <b>DIAMONDHUBPLUS</b>-->
<!--                    </a>-->
                    <!-- <div class="admin-logo logo-wrap-pro">
<!--                        <a href="http://daimondhubplus.com">-->
<!--                            <img src="/img/logo.jpg" alt="DaimondHubPlus" style="border-radius:50%; height: 40px; width: 40px;">-->
<!--                        </a>-->
<!--                    </div> -->-->
<!--                </div>-->
                
<!--                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">-->
<!--                    <div class="header-right-info">-->
<!--                        <ul class="nav navbar-nav mai-top-nav header-right-menu web-table" style="font-family: cosmic; font-size: 9px;">-->
                           
<!--                            <li class="nav-item">-->
<!--                                <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: cosmic; font-size: 12px;">-->
<!--                                     HOME                                                -->
<!--                                </a>                                            -->
<!--                            </li>-->
<!--                            <li class="nav-item">-->
<!--                                <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                    ABOUT US                                              -->
<!--                                </a>                                            -->
<!--                            </li>-->
<!--                            <li class="nav-item">-->
<!--                                <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                    FAQ                                              -->
<!--                                </a>                                            -->
<!--                            </li>-->
<!--                            <li class="nav-item">-->
<!--                                <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                    TERMS AND CONDITIONS                                              -->
<!--                                </a>                                            -->
<!--                            </li>-->
<!--                            <li class="nav-item">-->
<!--                                <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                    CONTACT US                                             -->
<!--                                </a>                                            -->
<!--                            </li>-->
<!--                            <li class="nav-item">-->
<!--                                <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                     OUR BLOG                                            -->
<!--                                </a>                                            -->
<!--                            </li>-->

<!--                            @if(\Request::is('register'))-->
<!--                                <li class="nav-item">-->
<!--                                    <a href="/login" data-toggle="" role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                         LOGIN                                           -->
<!--                                    </a>                                            -->
<!--                                </li>-->
<!--                            @elseif(\Request::is('login'))-->
<!--                                <li class="nav-item">-->
<!--                                    <a href="/register" data-toggle="" role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                         REGISTER                                         -->
<!--                                    </a>                                            -->
<!--                                </li>-->
<!--                            @else-->

<!--                                <li class="nav-item">-->
<!--                                    <a href="/login" data-toggle="" role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                         LOGIN                                           -->
<!--                                    </a>                                            -->
<!--                                </li>-->

<!--                                <li class="nav-item">-->
<!--                                    <a href="/register" data-toggle="" role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                         REGISTER                                         -->
<!--                                    </a>                                            -->
<!--                                </li>-->

<!--                            @endif-->
                            
                            
<!--                        </ul>-->

<!--                        <div class="dropdown  mobile_table" style="float: left; margin-top: -35px;">-->
<!--                          <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" style="background-color: transparent; border: none; color: #FFF;"><span class="fa fa-bars"></span>-->
<!--                          </button>-->
<!--                            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1" style="margin-right: 50px;">-->
<!--                                <li class="nav-item">-->
<!--                                    <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: cosmic; font-size: 12px;">-->
<!--                                         HOME                                                -->
<!--                                    </a>                                            -->
<!--                                </li>-->
<!--                                <div class="divider"></div>-->
<!--                                <li class="nav-item">-->
<!--                                    <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                        ABOUT US                                              -->
<!--                                    </a>                                            -->
<!--                                </li>-->
<!--                                <div class="divider"></div>-->
<!--                                <li class="nav-item">-->
<!--                                    <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                        FAQ                                              -->
<!--                                    </a>                                            -->
<!--                                </li>-->
<!--                                <div class="divider"></div>-->
<!--                                <li class="nav-item">-->
<!--                                    <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                        TERMS AND CONDITIONS                                              -->
<!--                                    </a>                                            -->
<!--                                </li>-->
<!--                                <div class="divider"></div>-->
<!--                                <li class="nav-item">-->
<!--                                    <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                        CONTACT US                                             -->
<!--                                    </a>                                            -->
<!--                                </li>-->
<!--                                <div class="divider"></div>-->
<!--                                <li class="nav-item">-->
<!--                                    <a href="#"  role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                         OUR BLOG                                            -->
<!--                                    </a>                                            -->
<!--                                </li>-->
<!--                                <div class="divider"></div>-->
<!--                                @if(\Request::is('register'))-->
<!--                                    <li class="nav-item">-->
<!--                                        <a href="/login" data-toggle="" role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                             LOGIN                                           -->
<!--                                        </a>                                            -->
<!--                                    </li>-->
<!--                                    <div class="divider"></div>-->
<!--                                @elseif(\Request::is('login'))-->
<!--                                    <li class="nav-item">-->
<!--                                        <a href="/register" data-toggle="" role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                             REGISTER                                         -->
<!--                                        </a>                                            -->
<!--                                    </li>-->
<!--                                    <div class="divider"></div>-->
<!--                                @else-->

<!--                                    <li class="nav-item">-->
<!--                                        <a href="/login" data-toggle="" role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                             LOGIN                                           -->
<!--                                        </a>                                            -->
<!--                                    </li>-->
<!--                                    <div class="divider"></div>-->

<!--                                    <li class="nav-item">-->
<!--                                        <a href="/register" data-toggle="" role="button" aria-expanded="false" class="nav-link dropdown-toggle" style="font-family: roboto; font-size: 12px;">-->
<!--                                             REGISTER                                         -->
<!--                                        </a>                                            -->
<!--                                    </li>-->

<!--                                @endif-->
<!--                            </ul>-->
<!--                        </div>-->


<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->


